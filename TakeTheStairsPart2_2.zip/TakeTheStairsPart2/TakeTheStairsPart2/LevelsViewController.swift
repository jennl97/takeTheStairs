//
//  LevelsViewController.swift
//  TakeTheStairsPart2
//
//  Created by Jenn Hott on 4/10/17.
//  Copyright © 2017 Jenn Hott. All rights reserved.
//

import UIKit
import CoreLocation
import HealthKit

class LevelsViewController: UIViewController, CLLocationManagerDelegate {
    @IBOutlet weak var timerLabel: UILabel!
    @IBOutlet weak var milesLabel: UILabel!
    @IBOutlet weak var heightLabel: UILabel!
    
    var zeroTime = TimeInterval()
    var timer = Timer()
    
    let locationManager = CLLocationManager()
    var startLocation: CLLocation!
    var lastLocation = CLLocation!.self
    var distanceTraveled = 0.0
    
    let healthManager:HealthKitManager = HealthKitManager()
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        locationManager.requestWhenInUseAuthorization()
        if CLLocationManager.locationServicesEnabled(){
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
        } else {
         print("Need to Enable Location")
       }
       getHealthKitPermission()
    }

  func getHealthKitPermission() {
    healthManager.authorizeHealthKit { (authorized, Error) -> Void in
            if authorized {
                self.setHeight()
          } else {
                if error != nil {
                    print(Error)
                }
                print("Permission Denied")
           }
    
        }
    }
    
   override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
