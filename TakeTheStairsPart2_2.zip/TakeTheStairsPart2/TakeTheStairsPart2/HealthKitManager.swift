//
//  HealthKitManager.swift
//  TakeTheStairsPart2
//
//  Created by Jenn Hott on 4/24/17.
//  Copyright © 2017 Jenn Hott. All rights reserved.
//

import UIKit
import HealthKit



let healthKitStore: HKHealthStore = HKHealthStore()



func authorizeHealthKit(completion:@escaping (Bool, Error?) -> Void)
{
    
    //state health data type from HK
    let healthDataToRead = Set(arrayLiteral: HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.height)!)
    
    //Health data type from HK
    let healthDataToWrite = Set(arrayLiteral: HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.distanceWalkingRunning)!)
    
    //tutorial says keep this in case it gets published!
    if !HKHealthStore.isHealthDataAvailable() {
        print("Can't access HealthKit.")
    }
    
    //read/write HK data
    healthKitStore.requestAuthorization (toShare: healthDataToWrite, read: healthDataToRead)
                                         { (success, error) -> Void in
                                            if (completion != nil) {
                                                completion(success, error)}
}

}
