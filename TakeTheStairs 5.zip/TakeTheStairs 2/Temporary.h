//
//  Temporary.h
//  TakeTheStairs
//
//  Created by Jenn Hott on 4/3/17.
//  Copyright © 2017 Jenn Hott. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>

@interface Temporary : NSObject

@end
