//
//  SwitchingViewController.swift
//  TakeTheStairs
//
//  Created by Jenn Hott on 3/20/17.
//  Copyright © 2017 Jenn Hott. All rights reserved.
//

import UIKit

class SwitchingViewController: UITabBarController {
    private var aboutViewController: AboutViewController!
    private var levelsViewController: LevelsViewController!
    private var progressViewController: ProgressViewController!
    private var historyViewController: HistoryViewController!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        aboutViewController = storyboard?.instantiateViewController(withIdentifier: "About")
        as! AboutViewController
        aboutViewController.view.frame = view.frame
        switchViewController(from: nil, to: aboutViewController)
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        if aboutViewController != nil && aboutViewController!.view.superview == nil {
            aboutViewController = nil
        }
        if levelsViewController != nil && levelsViewController!.view.superview == nil {
            levelsViewController = nil
        }
        if progressViewController != nil && progressViewController!.view.superview == nil {
            progressViewController = nil
        }
        if historyViewController != nil && historyViewController!.view.superview == nil {
            historyViewController = nil
        }
    }
    @IBAction func switchViews(sender: UIBarButtonItem) {
        if levelsViewController?.view.superview == nil {
            if levelsViewController == nil {
                levelsViewController = storyboard?.instantiateViewController(withIdentifier: "Levels")
                as! LevelsViewController
            }
            } else {
            if progressViewController?.view.superview == nil {
                if progressViewController == nil {
                    progressViewController = storyboard?.instantiateViewController(withIdentifier: "Progress")
                        as! ProgressViewController
                }
            
            } else {
            if historyViewController?.view.superview == nil {
                if historyViewController == nil {
                    historyViewController = storyboard?.instantiateViewController(withIdentifier: "History")
                        as! HistoryViewController
                }
            } else {
                if aboutViewController?.view.superview == nil {
                    if aboutViewController == nil {
                        aboutViewController = storyboard?.instantiateViewController(withIdentifier: "About")
                            as! AboutViewController
                    }
                
        }
        }
        }
        }

    
        
        //switch view controllers?
                if aboutViewController != nil && aboutViewController!.view.superview != nil {
                levelsViewController.view.frame = view.frame
                    switchViewController(from: aboutViewController,
                                         to: levelsViewController)
                } else {
                    if levelsViewController != nil && levelsViewController!.view.superview != nil {
                        progressViewController.view.frame = view.frame
                        switchViewController(from: levelsViewController,
                                             to: progressViewController)
                    } else {
                        if progressViewController != nil && progressViewController!.view.superview != nil {
                            historyViewController.view.frame = view.frame
                            switchViewController(from: progressViewController,
                                                 to: historyViewController)
                        } else {
                            if historyViewController != nil && historyViewController!.view.superview != nil {
                                aboutViewController.view.frame = view.frame
                                switchViewController(from: historyViewController,
                                                     to: aboutViewController)
                        }
                
                        
    }
    }
    }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    //Swift code for back button.
    /*self.navigationItem.backBarButtonItem = UIBarButtonItem(title:"", style:.Plain, target:nil, action:nil)*/
    
    private func switchViewController(from fromVC:UIViewController?,
                                      to toVC:UIViewController?) {
        if fromVC != nil {
            fromVC!.willMove(toParentViewController: nil)
            fromVC!.view.removeFromSuperview()
            fromVC!.removeFromParentViewController()
        }
        if toVC != nil {
            self.addChildViewController(toVC!)
            self.view.insertSubview(toVC!.view, at: 0)
            toVC!.didMove(toParentViewController: self)
        }
        
    }

}
