//
//  Temporary.m
//  TakeTheStairs
//
//  Created by Jenn Hott on 4/3/17.
//  Copyright © 2017 Jenn Hott. All rights reserved.
//

#import "Temporary.h"

@implementation Temporary

@end
