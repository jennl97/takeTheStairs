//
//  SwitchingViewController.swift
//  TakeTheStairs
//
//  Created by Jenn Hott on 3/20/17.
//  Copyright © 2017 Jenn Hott. All rights reserved.
//

import UIKit

class SwitchingViewController: UIViewController {
    private var aboutViewController: AboutViewController!
    private var levelsViewController: LevelsViewController!
    private var progressViewController: ProgressViewController!
    private var historyViewController: HistoryViewController!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func switchViews(sender: UIBarButtonItem) {
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    //Swift code for back button.
    /*self.navigationItem.backBarButtonItem = UIBarButtonItem(title:"", style:.Plain, target:nil, action:nil)*/

}
