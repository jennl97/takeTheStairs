//
//  LevelsViewController.swift
//  TakeTheStairsPart2
//
//  Created by Jenn Hott on 4/10/17.
//  Copyright © 2017 Jenn Hott. All rights reserved.
//

import UIKit
import CoreMotion


class LevelsViewController: UIViewController{
    @IBOutlet weak var stepsLabel: UILabel!
    @IBOutlet weak var paceLabel: UILabel!
    @IBOutlet weak var avgPaceLabel: UILabel!
    @IBOutlet weak var distanceLabel: UILabel!
    @IBAction func startStopButton(_ sender: UIButton){
    
    }
   
   override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
