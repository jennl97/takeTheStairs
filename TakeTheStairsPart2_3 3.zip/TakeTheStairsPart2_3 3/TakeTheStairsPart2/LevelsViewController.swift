//
//  LevelsViewController.swift
//  TakeTheStairsPart2
//
//  Created by Jenn Hott on 4/10/17.
//  Copyright © 2017 Jenn Hott. All rights reserved.
//
/*used https://makeapppie.com/2017/02/14/introducing-core-motion-make-a-pedometer/ to create pedometer */


import UIKit
import CoreMotion


class LevelsViewController: UIViewController{
    let stopColor = UIColor(red: 1.0, green: 0.0, blue: 0.0, alpha: 1.0)
    let startColor = UIColor(red: 0.0, green: 1.0, blue: 0.0, alpha: 1.0)
    
  //basic pedometer information
    var numberOfSteps: Int! = nil
    var distance:Double! = nil
    var averagePace:Double! = nil
    var pace:Double! = nil
    var pedometer = CMPedometer.self
    
    //begin to set timer
    var timer = Timer()
    let timerInverval = 1.0
    var timeElapsed:TimeInterval = 0.0
    
    
    @IBOutlet weak var stepsLabel: UILabel!
    
    @IBOutlet weak var paceLabel: UILabel!
    

    @IBOutlet weak var avePaceLabel: UILabel!
    
    
    @IBOutlet weak var distanceLabel: UILabel!
    
    @IBOutlet weak var statusTitle: UILabel!
    
    @IBAction func startStopButton(_ sender: UIButton) {
        if sender.titleLabel?.text == "Start"{
            //start pedometer and toggle the UI to ON
            let pedometer = CMPedometer()
            startTimer()
            pedometer.startUpdates(from: Date(), withHandler: { (pedometerData, error) in
                if let pedData = pedometerData{
                    self.numberOfSteps = Int(pedData.numberOfSteps)
                    self.stepsLabel.text = "Steps:\(pedData.numberOfSteps)"
                    if let distance = pedData.distance{
                        self.distance = Double(distance)
                    }
                    if let averageActivePace = pedData.averageActivePace {
                        self.averagePace = Double(averageActivePace)
                    }
                    if let currentPace = pedData.currentPace {
                        self.pace = Double(currentPace)
                    }
                } else {
                    self.numberOfSteps = nil
                }
            })
            
        //turn pedometer on
        statusTitle.text = "Pedometer On"
            sender.setTitle("Stop", for: .normal)
            sender.backgroundColor = stopColor
        } else {
            //stop pedometer and toggle UI to OFF
            stopTimer()
            statusTitle.text = "Pedometer Off" + timeIntervalFormat(interval: timeElapsed)
            sender.setTitle("Start", for: .normal)
            sender.backgroundColor = startColor
        }
   }
    
    // MARK: -Timer Functions
    func startTimer(){
        if timer.isValid { timer.invalidate()}
        timer = Timer.scheduledTimer(timeInterval: timerInverval,
                               target: self,
                               selector: #selector(displayPedometerData),
                               userInfo: nil,
                               repeats: true)
        
    }
    
    func stopTimer(){
        timer.invalidate()
        displayPedometerData()
    }
    

    func displayPedometerData(){
        timeElapsed += 1.0
        statusTitle.text = "On: " + timeIntervalFormat(interval: timeElapsed)
        //Number of steps
        if let numberOfSteps = self.numberOfSteps{
            stepsLabel.text = String(format:"Steps: %i",numberOfSteps)
        }
        
        //distance
        if let distance = self.distance{
            distanceLabel.text = String(format:"Distance: %02.02f meters,\n %02.02f mi",distance, miles(meters: distance))
        } else {
            distanceLabel.text = "Distance: N/A"
        }
        
        //average pace
        if let averagePace = self.averagePace{
            avePaceLabel.text = paceString(title: "Avg Pace", pace: averagePace)
        } else {
            avePaceLabel.text =  paceString(title: "Avg Comp Pace", pace: computedAvgPace())
        }
        
        //pace
        if let pace = self.pace {
            print(pace)
            paceLabel.text = paceString(title: "Pace:", pace: pace)
        } else {
            paceLabel.text = "Pace: N/A "
            paceLabel.text =  paceString(title: "Avg Comp Pace", pace: computedAvgPace())
        }
    }
    
    
    
     // MARK: - Display and time functions
    // convert seconds to hh:mm:ss as string
    
    func timeIntervalFormat(interval:TimeInterval) -> String {
        var seconds = Int(interval + 0.5) //rounds up the seconds
        let hours = seconds / 3600
        let minutes = (seconds / 60) % 60
        
        seconds = seconds % 60
        return String(format: "%02i:%02i:%02i", hours, minutes, seconds)
    }
    
    //convert pace into meters per seconds as string
    func paceString(title: String, pace: Double) -> String{
        var minPerMile = 0.0
        let factor = 26.8224 //conversion metric and Imperial
        
        if pace != 0 {
            minPerMile = factor / pace
        }
        let minutes = Int(minPerMile)
        let seconds = Int(minPerMile * 60) % 60
        return String(format: "%@: %02.0f m/s \n\t\t %02i:%02i min/mi", title, pace, minutes, seconds)
    }
    
    //compute average pace
        func computedAvgPace()-> Double {
            if let distance = self.distance {
              pace = distance/timeElapsed
                    return pace
            } else {
                return 0.0
            }
}

    //convert to miles
    func miles(meters:Double) -> Double{
        let miles = 0.000621371192
        return meters * miles
    }
    


}
